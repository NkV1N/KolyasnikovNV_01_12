﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KolyasnikovNV_01_12
{
    public class CarChildClass : CarClass
    {
        public int Year; // Год выпуска

        public CarChildClass (int mileAge, int consumption, int year) : base(mileAge, consumption) // Конструктор класса наследника
        {
            Year = year;
        }
        
        public override double GetQ () // Переопределенный метод базового класса
        {
            return base.GetQ() * 1.15 * Year; // Формула для класса наследнка
        }
    }
}
