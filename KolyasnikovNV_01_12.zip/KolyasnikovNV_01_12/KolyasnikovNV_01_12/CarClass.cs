﻿using System;

namespace KolyasnikovNV_01_12
{
    public class CarClass
    {
        public int MileAge; // Пробег
        public int Consumption; // Расход на км

        public CarClass (int mileAge, int consumption) // Конструктор базового класса
        {
            MileAge = mileAge;
            Consumption = consumption;
        }
        public virtual double GetQ () // Функция, которая определяет качество объекта – Q по заданной формуле
        {
            return MileAge / Consumption; // Формула для базового класса
        }
        
        public string GetInfo () // Метод для получения информации
        {
            return $"Пробег = {MileAge}\nРасход на км = {Consumption}\nВывод расчета = {GetQ()}";
        }
    }
}
