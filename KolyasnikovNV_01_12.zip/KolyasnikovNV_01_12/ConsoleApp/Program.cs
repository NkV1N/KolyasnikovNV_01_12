﻿using KolyasnikovNV_01_12;
using System;

namespace ConsoleApp
{
    class Program
    {
        static void Main (string[] args)
        {
            // Базовый класс
            CarClass carClass = new CarClass(15890, 10);
            // Вывод информации из базового класса
            Console.WriteLine(carClass.GetInfo());
            Console.WriteLine("-------------------------------------------");
            // Класс потомок
            CarChildClass carChildClass = new CarChildClass(20000, 15, 2015);
            // Вывод информации из класса потомка
            Console.WriteLine(carChildClass.GetInfo());
        }
    }
}
